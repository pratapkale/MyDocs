package S3;

import com.amazonaws.services.s3.AmazonS3;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class CreateBucket {


    public void createS3Bucket(){
        AWSClient client = new AWSClient();
        AmazonS3 s3client = client.getAwsClient();
        if(s3client.doesBucketExist(Constants.BUCKET_NAME))
        {
            System.out.println("Bucket name is not available."
                    + " Try again with a different Bucket name.");
            return;
        }
        s3client.createBucket(Constants.BUCKET_NAME);
    }

    public static void main(String[] args) {
        CreateBucket createBucket = new CreateBucket();
        createBucket.createS3Bucket();
    }


}
