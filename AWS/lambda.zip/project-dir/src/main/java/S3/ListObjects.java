package S3;

import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class ListObjects {

    public List<String> listObjects(){
        List<String> listObjectNames = new ArrayList<String>();
        ObjectListing objectListing = AWSClient.getAwsClient().listObjects(Constants.BUCKET_NAME);
        for(S3ObjectSummary os : objectListing.getObjectSummaries()) {
            listObjectNames.add(os.getKey());
            System.out.println(os.getKey());
        }
        return  listObjectNames;
    }

    public static void main(String[] args) {
        new ListObjects().listObjects();
    }
}
