package S3;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class Constants {
    static String BUCKET_NAME = "aws-training-22jan2";

}
