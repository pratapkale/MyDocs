package S3;


import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class ReadObject {

    private void downloadFromBucket(String bucketName,String objectName){
        try {
            S3Object s3object = AWSClient.getAwsClient().getObject(bucketName, objectName);
            S3ObjectInputStream inputStream = s3object.getObjectContent();
            String i;
            BufferedReader read = new BufferedReader( new InputStreamReader(inputStream));
            while ((i = read.readLine()) != null)
                System.out.println(i);
            read.close();
            //FileUtils.copyInputStreamToFile(inputStream, new File("/D:/training/download/hello.txt"));
        } catch (Exception e){
          e.printStackTrace();
        }
    }

    private void readObjectFromBucketPubliclly(){
        try {
            URL url = new URL("https://my-bucket-27dec19.s3.us-east-2.amazonaws.com/hello.txt");
            BufferedReader read = new BufferedReader(
                    new InputStreamReader(url.openStream()));

            String i;
            while ((i = read.readLine()) != null)
                System.out.println(i);
            read.close();
            //System.out.println(url.getFile());
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new ReadObject().downloadFromBucket(Constants.BUCKET_NAME,"hello.txt");
    }
}
