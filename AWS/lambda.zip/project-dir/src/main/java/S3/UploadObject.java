package S3;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class UploadObject {
    public  void createObjectInBucket(String key, String content){
        AWSClient.getAwsClient().putObject(
                Constants.BUCKET_NAME,
                key,
                content
        );
    }

    public static void main(String[] args) {
        UploadObject uploadObject = new UploadObject();
        uploadObject.createObjectInBucket("testFile.txt","vishal");
    }

}
