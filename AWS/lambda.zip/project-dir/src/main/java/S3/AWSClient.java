package S3;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class AWSClient {

    private static String ACCESS_KEY ="AKIARMFNOM4OIYS6DN5U";
    private static String SECRET_KEY ="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";

    public static AmazonS3 getAwsClient(){
        AmazonS3 s3client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(getCredentials()))
                .withRegion(Regions.US_EAST_1)
                .build();
        return s3client;
    }

    private static AWSCredentials getCredentials(){
        AWSCredentials credentials = new BasicAWSCredentials(
                ACCESS_KEY,
                SECRET_KEY
        );
        return credentials;
    }

}
