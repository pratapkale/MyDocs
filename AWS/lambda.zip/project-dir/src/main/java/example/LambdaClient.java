package example;


import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class LambdaClient implements RequestHandler<RequestClass, ResponseClass> {


    public ResponseClass handleRequest(RequestClass request, Context context){
        String greetingString = String.format("Hello 14 feb %s, %s.", request.firstName, request.lastName);
        return new ResponseClass(greetingString);
    }

}