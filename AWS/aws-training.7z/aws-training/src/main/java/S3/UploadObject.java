package S3;

import com.amazonaws.services.s3.AmazonS3;

import java.io.File;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class UploadObject {
    public  void createObjectInBucket(){
        AWSClient.getAwsClient().putObject(
                Constants.BUCKET_NAME,
                "hello.txt",
                "Hello vishal"
        );
    }

    public static void main(String[] args) {
        UploadObject uploadObject = new UploadObject();
        uploadObject.createObjectInBucket();
    }

}
