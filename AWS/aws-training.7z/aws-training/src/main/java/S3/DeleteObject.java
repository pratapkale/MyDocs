package S3;

/**
 * Created by vishal.sarathe on 27-12-2019.
 */
public class DeleteObject {

    private void deleteObject(){
        for(String objectName:new ListObjects().listObjects()){
            System.out.println(objectName);
            if(!objectName.equals("hello.txt")){
                AWSClient.getAwsClient().deleteObject(Constants.BUCKET_NAME,objectName);
            }
        }
    }

    public static void main(String[] args) {
        new DeleteObject().deleteObject();
    }
}
