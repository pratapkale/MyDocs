package database;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by vishal.sarathe on 30-12-2019.
 */
public class CreateTable {
    public static String  CREATE_PERSON_TABLE = "CREATE TABLE AWS_TRAINING_7JAN.PERSON (PERSON_ID INT(11), PERSON_NAME VARCHAR(30))";

    void createTable(){
         //dbConnection = new DBConnection();
        Connection connection = DBConnection.getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(CREATE_PERSON_TABLE);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new CreateTable().createTable();
    }
}
