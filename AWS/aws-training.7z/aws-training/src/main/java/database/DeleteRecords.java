package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by vishal.sarathe on 30-12-2019.
 */
public class DeleteRecords {
    public static String  DELETE_PERSON = "DELETE FROM PERSON_DB.PERSON WHERE PERSON_ID = ?";

    void deleteRecords(int personId){
        //DBConnection dbConnection = new DBConnection();
        Connection connection = DBConnection.getConnection();
        try {
            PreparedStatement preparedStmt = connection.prepareStatement(DELETE_PERSON);
            preparedStmt.setInt(1,personId);
            preparedStmt.executeUpdate();
            System.out.println("records deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

    }

}
