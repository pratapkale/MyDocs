package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by vishal.sarathe on 30-12-2019.
 */
public class UpdateRecords {
    public static String  UPDATE_PERSON = "UPDATE PERSON_DB.PERSON SET PERSON_NAME =? WHERE PERSON_ID = ?";


    void updateRecords(int personId,String personName){
        // dbConnection = new DBConnection();
        Connection connection = DBConnection.getConnection();
        try {
            PreparedStatement preparedStmt = connection.prepareStatement(UPDATE_PERSON);
            preparedStmt.setString(1,personName);
            preparedStmt.setInt(2,personId);
            preparedStmt.executeUpdate();
            System.out.println("records updated successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

    }
}
