package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by vishal.sarathe on 30-12-2019.
 */
public class ReadRecords {
    public static String  SELECT_PERSON = "SELECT * FROM PERSON_SCHEMA.PERSON_INFO WHERE PERSON_ID =?";


    void selectRecords(int personId){
      //   dbConnection = new DBConnection();
        Connection connection = DBConnection.getConnection();
        try {
            PreparedStatement preparedStmt = connection.prepareStatement(SELECT_PERSON);
            preparedStmt.setInt(1,personId);
            ResultSet resultSet  = preparedStmt.executeQuery();
            while (resultSet.next()){
                int id = resultSet.getInt("PERSON_ID");
                String firstName = resultSet.getString("PERSON_NAME");
                System.out.format("%s, %s\n", id, firstName);
            }
            System.out.println("records read successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

     new ReadRecords().selectRecords(101);

    }

    private void DbCrudOperation(){
        System.out.println("Inserting recods");
        new InsertRecords().insertRecords(101,"kammo");
        new ReadRecords().selectRecords(101);

        System.out.println("Updating recods");
        new UpdateRecords().updateRecords(101,"sarathe");
        new ReadRecords().selectRecords(101);

        System.out.println("Delete recods");
        new DeleteRecords().deleteRecords(101);
        new ReadRecords().selectRecords(101);
    }
}
