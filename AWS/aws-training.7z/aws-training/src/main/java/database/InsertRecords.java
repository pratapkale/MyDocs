package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by vishal.sarathe on 30-12-2019.
 */
public class InsertRecords {
    public static String  INSERT_PERSON = "INSERT INTO PERSON_DB.PERSON VALUES (?, ?);";


    void insertRecords(int personId, String PersonName){
         //dbConnection = new DBConnection();
        Connection connection = DBConnection.getConnection();
        try {
            PreparedStatement preparedStmt = connection.prepareStatement(INSERT_PERSON);
            preparedStmt.setInt(1,personId);
            preparedStmt.setString (2, PersonName);
            preparedStmt.execute();
            System.out.println("records inserted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
          new InsertRecords().insertRecords(103,"vishal");
    }
}
