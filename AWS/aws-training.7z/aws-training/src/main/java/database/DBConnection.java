package database;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Created by vishal.sarathe on 30-12-2019.
 */
public class DBConnection {
    String db_hostname;
    String db_username;
    String db_password;
    String db_database;
    private static Connection conn = null;
    private DBConnection(){
        try {
            Properties prop = new Properties();
            InputStream input = DBConnection.class.getClassLoader().getResourceAsStream("db.properties");
            prop.load(input);
            this.db_hostname = prop.getProperty("db_hostname");
            this.db_username = prop.getProperty("db_username");
            this.db_password = prop.getProperty("db_password");
            this.db_database = prop.getProperty("db_database");
            System.out.println(db_hostname);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public static Connection getConnection() {
        if(conn ==null) {
            try {
                DBConnection dbConnection = new DBConnection();
                //Class.forName("com.mysql.jdbc.Driver").newInstance();
                conn = DriverManager.getConnection(dbConnection.db_hostname, dbConnection.db_username, dbConnection.db_password);
                return conn;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        System.out.println(conn.toString());
        return conn;
    }

}
