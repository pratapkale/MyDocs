package version8;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;

import static java.util.stream.Collectors.toMap;

/**
 * Created by vishal.sarathe on 07-01-2020.
 */
public class ClientImpl{



    public void log(String s){
        System.out.println("from overided 1");
    }

    public static void main(String[] args) {
      // new ClientImpl().methodExpression();
     //  new ClientImpl().streamPrograming();
      // new ClientImpl().oldWay();
        System.out.println(new ClientImpl().sumStream());
    }

    void methodExpression(){

        /*interface1 int1 = new interface1() {
            @Override
            public void log(String s) {
                System.out.println("test..."+s);
            }
        };
        int1.log("vishal");*/

        interface1 int2 = s-> System.out.println("test..."+s);


       // int2.testLog("vishal1");

        // create a list of strings
        List<String> names =
                Arrays.asList("Geek","GeeksQuiz","g1","QA","Geek2");

        // declare the predicate type as string and use
        // lambda expression to create object
        Predicate<String> p = (s)->s.startsWith("G");
        Function p1 = (s)-> s;

        // Iterate through the list
        for (String st:names)
        {
            // call the test method
          //  if (p.test(st))
                //System.out.println(st);
        }

        System.out.println(p1.apply("test"));

    }

    void streamPrograming() {
        List<String> names = new ArrayList<String>();
        names.add("a");
        names.add("b");
        names.add("c");
        /*Iterator<String> itr =  names.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }*/
        Map<String, Integer> result = names.stream()
                .collect(toMap(Function.identity(), String::length));
        System.out.println(result);
    }

    void oldWay(){
        List<String> names = new ArrayList<String>();
        names.add("a");
        names.add("b");
        names.add("c");
        Iterator<String> itr =  names.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
           // System.out.println(itr.next());
        }
    }

    int sumStream(){
        List<Integer> list = new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

       return list.stream().filter(i-> i >2).mapToInt(i->i).sum();
    }

}
