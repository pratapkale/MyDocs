package version8;

/**
 * Created by vishal.sarathe on 07-01-2020.
 */
public interface interface2 {
    default void log(String s){
        System.out.println("Hello From :"+s);
    }

    static void test(){}
}
